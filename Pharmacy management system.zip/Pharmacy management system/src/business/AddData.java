
package business;

import java.util.ArrayList;


public class AddData {
    
    public void setInitialValues(PharmacyDirectory pharmacyDirectory)
            
    {
        PharmacyDirectory pharmaDirectory = pharmacyDirectory;
        
       Pharmacy pharma1 = new Pharmacy();
               
       Pharmacy pharma2 = new Pharmacy();
       
               
       pharma1.setStoreName("pharma1");
       pharma2.setStoreName("pharma2");
        
       pharmaDirectory.addPharmacy(pharma1);
      pharmaDirectory.addPharmacy(pharma2);
        Drug drug1 = new Drug();
        
        
        //drug1.setDrugID(1);
        drug1.setDrugName("PANADOL");
        drug1.setDrugType("paracetemol");
        drug1.setComposition("paracetemol ");
        drug1.setDrugAvailibility(100);
        drug1.setDrugPrice(50);
        drug1.setDrugDescription("used for Pain/Fever");
        drug1.setExpirationDate("20-05-2018");
        drug1.setManufacturedDate("10-09-2015");
        pharma1.getDrugCatalog().addDrugs(drug1);
        
        Drug drug2 = new Drug();
        //drug2.setDrugID(2);
        drug2.setDrugName("Evion E");
        drug2.setDrugType("Vitamin E");
        drug2.setComposition("Vitamin E");
        drug2.setDrugAvailibility(80);
        drug2.setDrugPrice(30);
        drug2.setDrugDescription("used for Antioxidant");
        drug2.setExpirationDate("20-10-2018");
        drug2.setManufacturedDate("10-10-2015");
        pharma1.getDrugCatalog().addDrugs(drug2);
        
        Drug drug12 = new Drug();
        //drug12.setDrugID(3);
        drug12.setDrugName("Brufen");
        drug12.setDrugType("anti Allergy");
        drug12.setComposition("antacid ");
        drug12.setDrugAvailibility(80);
        drug12.setDrugPrice(30);
        drug12.setDrugDescription("used for Fever");
        drug12.setExpirationDate("20-10-2018");
        drug12.setManufacturedDate("10-10-2015");
        pharma2.getDrugCatalog().addDrugs(drug12);
        
    }
    public void setStoreInitialValues(StoreDirectory storeDirectory){
        StoreDirectory sd = storeDirectory;
        
        Store store1 = new Store();
        
        Store store2 = new Store();
        
        
        store2.setStoreName("Zaid Store");
        store2.setStoreLocation("Sawabi");
        sd.addStore(store2);
        
        store1.setStoreName("Hassan Store");
        store1.setStoreLocation("Abbottabad");
        sd.addStore(store1);
        
       
    }
                
}
