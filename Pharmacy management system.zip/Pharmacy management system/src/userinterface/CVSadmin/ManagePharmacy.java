package userinterface.CVSadmin;

import business.Pharmacy;
import business.PharmacyDirectory;
import java.awt.CardLayout;
import java.awt.Color;
import java.util.function.Supplier;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class ManagePharmacy extends javax.swing.JPanel {

  JPanel userProcessContainer;
 PharmacyDirectory pharmacyDirectory;
    public ManagePharmacy(JPanel userProcessConatiner, PharmacyDirectory pharmacyDirectory) {
        initComponents();
        this.userProcessContainer = userProcessConatiner;
        this.pharmacyDirectory = pharmacyDirectory;
        populateTable();
        
    }
    void populateTable() {
        DefaultTableModel dtm = (DefaultTableModel) pt.getModel();
        dtm.setRowCount(0); 
     /*int rowCount = accountJTable.getRowCount();*/
        for (Pharmacy pharmacy : pharmacyDirectory.getStoreList())
        {
            Object[] row = new Object[1];
            row[0]=pharmacy;
            dtm.addRow(row);
        }
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBack = new javax.swing.JButton();
        rem = new javax.swing.JButton();
        view = new javax.swing.JButton();
        addp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        pt = new javax.swing.JTable();

        setBackground(new java.awt.Color(204, 204, 255));

        btnBack.setBackground(new java.awt.Color(0, 204, 204));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBack.setText("<<Back");
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBackMouseClicked(evt);
            }
        });
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        rem.setBackground(new java.awt.Color(0, 204, 204));
        rem.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rem.setText("Remove");
        rem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                remMouseEntered(evt);
            }
        });
        rem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                remActionPerformed(evt);
            }
        });

        view.setBackground(new java.awt.Color(0, 204, 204));
        view.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        view.setText("View Pharmacy");
        view.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewMouseEntered(evt);
            }
        });
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewActionPerformed(evt);
            }
        });

        addp.setBackground(new java.awt.Color(0, 204, 204));
        addp.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        addp.setText("Add Pharmacy");
        addp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addpMouseEntered(evt);
            }
        });
        addp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addpActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel1.setText("                       Manage Pharmacy");

        pt.setBackground(new java.awt.Color(255, 0, 255));
        pt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "PHARMACIES"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(pt);
        if (pt.getColumnModel().getColumnCount() > 0) {
            pt.getColumnModel().getColumn(0).setHeaderValue("PHARMACIES");
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rem, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(177, 177, 177)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(view, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addp, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)))
                .addGap(412, 412, 412))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(98, 98, 98)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rem, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(view, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addp, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(45, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addpActionPerformed
        AddPharmacy aph = new AddPharmacy(userProcessContainer,pharmacyDirectory);
        userProcessContainer.add("add pharmacy",aph);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_addpActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        
        int selectedRow = pt.getSelectedRow();
        if(selectedRow<0){
            JOptionPane.showMessageDialog(null, "Please select a row to view","Warning",JOptionPane.WARNING_MESSAGE);
            return;
        }
        Pharmacy pharmacy = (Pharmacy) pt.getValueAt(selectedRow, 0);
        ViewPharmacyDetails viewpharmadetailsPanel = new ViewPharmacyDetails(userProcessContainer,pharmacy);
        userProcessContainer.add("viewpharmadetailsPanel",viewpharmadetailsPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
        
        
    }//GEN-LAST:event_viewActionPerformed

    private void remActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_remActionPerformed
        int selectedRow = pt.getSelectedRow();
        if(selectedRow<0){
            JOptionPane.showMessageDialog(null, "Please select a row to view","Warning",JOptionPane.WARNING_MESSAGE);
            return;
        }
        int dialogResult = JOptionPane.showConfirmDialog(null, "Please confirm to delete", "Delete confirmation", JOptionPane.WARNING_MESSAGE);
             if(dialogResult == JOptionPane.YES_OPTION){
         Pharmacy pharmacy = (Pharmacy) pt.getValueAt(selectedRow, 0);
         pharmacyDirectory.removeSupplier(pharmacy);
         populateTable();
             }
    }//GEN-LAST:event_remActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void remMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_remMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_remMouseEntered

    private void viewMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewMouseEntered
        // TODO add your handling code here:
        view.setBackground(Color.magenta);
    }//GEN-LAST:event_viewMouseEntered

    private void btnBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseClicked
        // TODO add your handling code here:
        btnBack.setBackground(Color.red);
    }//GEN-LAST:event_btnBackMouseClicked

    private void addpMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addpMouseEntered
addp.setBackground(Color.gray);        // TODO add your handling code here:
        
    }//GEN-LAST:event_addpMouseEntered


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addp;
    private javax.swing.JButton btnBack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable pt;
    private javax.swing.JButton rem;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables

}
