package userinterface.CVSadmin;

import business.Drug;
import business.DrugCatalog;
import business.Pharmacy;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class ViewPharmacyCompany extends javax.swing.JPanel {
    
    JPanel userProcessContainer;
  Pharmacy pharmacy;
    public ViewPharmacyCompany(JPanel userProcessConatiner, Pharmacy pharmacy) {
        initComponents();
        this.userProcessContainer =  userProcessConatiner;
        this.pharmacy = pharmacy;
//        addDrugsJButton.setEnabled(false);
        populateTable();
        pharmacyNameLabelName.setText(pharmacy.getStoreName()); //to get supplier name as label above the abv
    }
    
    public void populateTable()
    {
        DefaultTableModel dtm = (DefaultTableModel) ct.getModel();
        dtm.setRowCount(0); //to make row count 0
       // int rowCount = accountJTable.getRowCount();
        for (Drug drugs : pharmacy.getDrugCatalog().getDrugList())
        {
            Object[] row = new Object[3];
            row[0]=drugs;
            row[1]=drugs.getDrugID();
            row[2]=drugs.getDrugAvailibility();
            
            dtm.addRow(row);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pharmacyNameLabelName = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ct = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        addd = new javax.swing.JButton();

        setBackground(new java.awt.Color(153, 255, 0));

        pharmacyNameLabelName.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        pharmacyNameLabelName.setText("DETAILS");

        ct.setBackground(new java.awt.Color(204, 204, 255));
        ct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Drug Name", "Drug Id", "Drug Availibility"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ct);

        btnBack.setBackground(new java.awt.Color(255, 204, 204));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        addd.setBackground(new java.awt.Color(255, 204, 204));
        addd.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        addd.setText("Add Drugs");
        addd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adddMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                adddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                adddMouseExited(evt);
            }
        });
        addd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adddActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(188, 188, 188)
                                .addComponent(addd))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(pharmacyNameLabelName, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(303, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(pharmacyNameLabelName, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(addd, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(188, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void adddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adddActionPerformed
        // TODO add your handling code here:
        DrugCatalog drugCatalog = pharmacy.getDrugCatalog();
        AddDrugsJPanel addDrugsJPanel = new AddDrugsJPanel(userProcessContainer,drugCatalog);
        userProcessContainer.add("addDrugsJPanel",addDrugsJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_adddActionPerformed

    private void adddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adddMouseEntered
        // TODO add your handling code here:
        addd.setBackground(Color.red);
    }//GEN-LAST:event_adddMouseEntered

    private void adddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adddMouseExited
        // TODO add your handling code here:
        addd.setBackground(Color.cyan);
    }//GEN-LAST:event_adddMouseExited

    private void adddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adddMouseClicked
        // TODO add your handling code here:
          addd.setBackground(Color.yellow);
        
    }//GEN-LAST:event_adddMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addd;
    private javax.swing.JButton btnBack;
    private javax.swing.JTable ct;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel pharmacyNameLabelName;
    // End of variables declaration//GEN-END:variables
}
